/*=============== CHANGE BACKGROUND HEADER ===============*/
function scrollHeader(){
    const header = document.getElementById('header')
    if(this.scrollY >= 50) header.classList.add('scroll-header'); else header.classList.remove('scroll-header')
}
window.addEventListener('scroll', scrollHeader)
/*=============== SERVICES MODAL ===============*/
const modalViews = document.querySelectorAll('.services_modal'),
      modalBtns = document.querySelectorAll('.services_button'),
      modalClose = document.querySelectorAll('.services_modal-close')
let modal = function(modalClick){
    modalViews[modalClick].classList.add('active-modal')
}
modalBtns.forEach((mb, i) =>{
    mb.addEventListener('click', () =>{
        modal(i)
    })
})
modalClose.forEach((mc) =>{
    mc.addEventListener('click', () =>{
        modalViews.forEach((mv)=>{
            mv.classList.remove('active-modal')
        })
    })
})
/*=============== MIXITUP FILTER PORTFOLIO ===============*/
let mixerPortafolio = mixitup('.work_container', {
    selectors:{
        target: '.work_card'
    },
    animation:{
        duration: 300
    }
})

const linkWork = document.querySelectorAll('.work_item')
function activeWork(){
    linkWork.forEach(L => L.classList.remove('active-work'))
    this.classList.add('active-work')
}
linkWork.forEach(L=>L.addEventListener('click', activeWork))
/*=============== SWIPER TESTIMONIAL ===============*/
var swipertestimonial = new Swiper(".testimonial_container", {
    spaceBetween: 24,
    loop:true,
    grabCursor:true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    breakpoints: {
        576: {
          slidesPerView: 2,
        },
        768: {
          slidesPerView: 2,
          spaceBetween: 40,
        },
    }
  });

/*=============== SCROLL SECTIONS ACTIVE LINK ===============*/
const sections = document.querySelectorAll('section[id]')

function scrollActive(){
    const scrollY = window.pageYOffset

    sections.forEach(current =>{
        const sectionHeight = current.offsetHeight,
              sectionTop = current.offsetTop - 58,
              sectionId = current.getAttribute('id')
                
        if(scrollY > sectionTop && scrollY <= sectionTop + sectionHeight){
            document.querySelector('.nav_menu a[href*=' + sectionId + ']').classList.add('active_link')
        }else{
            document.querySelector('.nav_menu a[href*=' + sectionId + ']').classList.remove('active_link')
        }
    })
}
window.addEventListener('scroll', scrollActive)
/*=============== LIGHT DARK THEME ===============*/ 
const themeButton = document.getElementById('theme_button')
const lightTheme = 'light-theme'
const iconTheme = 'bx-sun'

const selectedTheme = localStorage.getItem('selected-theme')
const selectedIcon = localStorage.getItem('selected-icon')

const getCurrentTheme = () => document.body.classList.contains(lightTheme) ? 'dark' : 'light'
const getCurrentIcon = () => themeButton.classList.contains(iconTheme) ? 'bx bx-moon' : 'bx bx-sun'

if (selectedTheme) {
  document.body.classList[selectedTheme === 'dark' ? 'add' : 'remove'](lightTheme)
  themeButton.classList[selectedIcon === 'bx bx-moon' ? 'add' : 'remove'](iconTheme)
}

themeButton.addEventListener('click', () => {
    document.body.classList.toggle(lightTheme)
    themeButton.classList.toggle(iconTheme)
    localStorage.setItem('selected-theme', getCurrentTheme())
    localStorage.setItem('selected-icon', getCurrentIcon())
}) ? 'bx bx-moon' : 'bx bx-sun'
/*=============== SCROLL REVEAL ANIMATION ===============*/

const sr = ScrollReveal({
    origin:'top',
    distance:'60px',
    duration:2500,
    delay:400,
    reset:true
})
sr.reveal('.home_data')
sr.reveal('.home_handle', {delay:500})
sr.reveal('.home_social, .home_scroll', {delay:500, origin:'bottom'})

/*=============== CONTACT ===============*/
$('.carga').hide()
const form = document.getElementById("formContact")
form.addEventListener('submit', function(e){
    e.preventDefault()
    $('.carga').show()
    const postData = {
        name: $('#name').val(),
        mail: $('#email').val(),
        number: $('#tel').val(),
        mensaje: $('#mensaje').val(),
        address: "ricardo_riveravalerio@hotmail.com"
      };
    const url = 'assets/php/enviar.php';
    console.log(postData, url);
    $.post(url, postData, (response) => {
        if(response=='correcto'){
            $('.carga').hide()
            $("#formContact").trigger("reset");
        }else{
            alert('Error en el envio de mensaje')
        }
    });
})