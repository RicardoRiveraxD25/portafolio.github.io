<?php
$name = (isset($_POST['name'])) ? $_POST['name'] : '';
$email = (isset($_POST['mail'])) ? $_POST['mail'] : '';
$number = (isset($_POST['number'])) ? $_POST['number'] : '';
$mensaje = (isset($_POST['mensaje'])) ? $_POST['mensaje'] : '';
$address = (isset($_POST['address'])) ? $_POST['address'] : '';
require 'phpmailer/src/Exception.php';
require_once 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';
require 'phpmailer/src/OAuth.php';

$mail = new PHPMailer\PHPMailer\PHPMailer(); 
$mail->Debugoutput = 'html';
$mail->CharSet = 'UTF-8';

try {
$mail->isSMTP();                                            
$mail->Host       = 'smtp.gmail.com';                   
$mail->SMTPAuth   = true;                                   
$mail->Username   = 'negro.zor@gmail.com';                  
$mail->Password   = 'rivera25xd';                              
$mail->SMTPSecure = 'tls';         
$mail->Port       = 587;       

$mail->setFrom('negro.zor@gmail.com', 'Postafolio');
$mail->addAddress($address);   

$mail->isHTML(true);                                  
$mail->Subject = 'Postafolio';
$mail->Body    = "
<html>
<head>
<title>Datos de formulario de campaña de Adwords</title>
<meta http-equiv='content-type' content='text/html; charset= utf-8'>
<meta name='viewport' content='widht=device-widht, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <style type='text/css' media='screen'>
    body div{
        width: 100%;
        margin: 0 auto;
        overflow: hidden;
        padding-bottom: 4%;
        padding-top: 4%;
        }
        .headers{
            height: 10%;
            font-family: 'Open Sans';
            font-size: 16px;
            color: #FFF;
            width: 100%;
            margin: 0 auto;
            text-align: center;
            overflow: hidden;
            background-color: #d43a4b;
            background-image: url('https://peperonidigital.mx/img/portada/wallpeaper-PEPERONI-GOOGLE-BUSCADOR.png');
            box-shadow: 0px 6px 6px 0.00px rgba(0, 0, 0, 0.18);
          }
          .headers h1{
            font-family: 'Open Sans';
            font-size: 18px;
            text-align: center;
            padding-top: 3.8%;
            color: #FFF;
          }
          .headers img{
            width: 80px; height: 80px;
            float: left;
            margin-left:10px;
          }
          .nombre{
            font-family: 'Open Sans';
            font-size: 16px;
            width: 95%;
            margin: 0 auto;
            overflow: hidden;
          }
          .mensaje{
            font-family: 'Open Sans';
            font-size: 16px;
            width: 95%;
            margin: 0 auto;
            overflow: hidden;
          }
          .cuerpo{
            width: 95%;
            margin: 0 auto;
            overflow: hidden;
            box-shadow: 0px 6px 16px 0.00px rgba(0, 0, 0, 0.18);  
          }
          footer{
            height: 10%;
            font-family: 'Open Sans';
            width: 100%;
            margin: 0 auto;
            overflow: hidden;
            background-color: #d43a4b;
            background-image: url('https://peperonidigital.mx/img/portada/wallpeaper-PEPERONI-GOOGLE-BUSCADOR.png');
            box-shadow: 0px 6px 16px 0.00px rgba(0, 0, 0, 0.18);
          }
           footer p{
            font-family: 'Open Sans';
            font-size: 12px;
            text-align: center;
            padding-top: 2%;
            margin: 10 auto;
            overflow: hidden;
            color: #FFF;
            width: 90%;
           }
</style>
</head>
<body>
<div>
<div class='headers'>
<h1>Mensaje enviado de: Protafolio</h1>

</div>
<div class='cuerpo'>
<section class='nombre'>
<p><b>De: </b> ".$name."
<br>
<p><b>Correo: </b> ".$email."
<br>
<p><b>WhatsApp: </b> ".$number."
<br>
</section>
<section class='mensaje'>
<p><b>Mensaje: </b>".$mensaje."
</section>
</div>
</div>
</body>
</html>";

$mail->send();
echo 'correcto';
} catch (Exception $e) {
echo "<p style='color:red'>Mensaje no enviado. Error de Email: {$mail->ErrorInfo} </p>";
}
?>