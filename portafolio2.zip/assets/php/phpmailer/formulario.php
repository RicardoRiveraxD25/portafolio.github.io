<html>
    <head>
      <title>Datos de formulario de campaña de Adwords</title>
       <meta http-equiv='content-type' content='text/html; charset= utf-8'>
        <meta name='viewport' content='widht=device-widht, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0'>
        <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
        <style type='text/css' media='screen'>
body div{
width: 100%;
margin: 0 auto;
overflow: hidden;
padding-bottom: 4%;
padding-top: 4%;
}
.headers{
    height: 10%;
    font-family: 'Open Sans';
    font-size: 16px;
    color: #FFF;
    width: 100%;
    margin: 0 auto;
    text-align: center;
    overflow: hidden;
    background-color: #d43a4b;
    background-image: url('https://peperonidigital.mx/wp-content/uploads/2020/10/fondopuntos.jpg');
    box-shadow: 0px 6px 6px 0.00px rgba(0, 0, 0, 0.18);
  }
  .headers h1{
    font-family: 'Open Sans';
    font-size: 18px;
    text-align: center;
    padding-top: 3.8%;
    color: #FFF;
  }
  .headers img{
    width: 75px; height: 75px;
    float: left;
    margin-left:10px;
  }
  .nombre{
    font-family: 'Open Sans';
    font-size: 16px;
    width: 95%;
    margin: 0 auto;
    overflow: hidden;
  }
  .mensaje{
    font-family: 'Open Sans';
    font-size: 16px;
    width: 95%;
    margin: 0 auto;
    overflow: hidden;
  }
  .cuerpo{
    width: 95%;
    margin: 0 auto;
    overflow: hidden;
    box-shadow: 0px 6px 16px 0.00px rgba(0, 0, 0, 0.18);  
  }
  footer{
    height: 10%;
    font-family: 'Open Sans';
    width: 100%;
    margin: 0 auto;
    overflow: hidden;
    background-color: #d43a4b;
    background-image: url('https://peperonidigital.mx/wp-content/uploads/2020/10/fondopuntos.jpg');
    box-shadow: 0px 6px 16px 0.00px rgba(0, 0, 0, 0.18);
  }
   footer p{
    font-family: 'Open Sans';
    font-size: 12px;
    text-align: center;
    padding-top: 2%;
    margin: 10 auto;
    overflow: hidden;
    color: #FFF;
    width: 80%;
  }
 </style>
</head>
<body>
<div>
<div class='headers'>
<img src="https://peperonidigital.mx/wp-content/uploads/2020/10/logo-PEPERONI-DIGITAL-CMYK-2.png" alt="">
<h1>Menaje enviado de: peperonidigital.mx</h1>

</div>
<div class='cuerpo'>
<section class='nombre'>
  <p><b>De: </b> "name"
  <br>
  <br>
  <b>Telefono: </b> ". $number ."
  <br>
  <br>
  <b>Email: </b> ". $email ."
</section>
<section class='mensaje'>
<p><b>Mensaje: </b>Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestiae, ullam cumque. Tenetur voluptas temporibus ipsum, placeat pariatur ratione, id quia suscipit iste eveniet similique perspiciatis cum odit assumenda maiores odio.</p>
</section>
</div>
<footer>
<p>&copy; 2021 peperonidigital.mx</p>
</footer>
</div>
</body>
</html>